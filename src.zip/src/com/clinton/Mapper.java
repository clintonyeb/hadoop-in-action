package com.clinton;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Mapper {
    private List<Pair<String, Integer>> pairs;

    private Mapper(){
        pairs = new ArrayList<>();
    }

    public static Mapper getInstance(String fileName) throws IOException {
        Mapper mapper = new Mapper();
        mapper.generatePairsFromFile(fileName);
//        mapper.pairs.sort(Comparator.comparing(p -> p.key));
        return mapper;
    }

    private void generatePairsFromFile(String fileName) throws IOException {
        Files.lines(Paths.get(fileName)).forEach(this::processLine);
    }

    private void processLine(String line) {
        for (String word : line.split("[\\s-]+")) {
            String formattedWord = getFormattedWord(word);
            if(formattedWord != null) pairs.add(new Pair<>(formattedWord, 1));
        }
    }

    private String getFormattedWord(String w) {
        String word = w.toLowerCase();
        StringBuilder res = new StringBuilder();
        for (int i = 0; i < word.length(); i++) {
            char c = word.charAt(i);
            if(!Character.isLetter(c)) {
                if(i != 0 && i != word.length()-1) return null;
            } else {
                res.append(c);
            }
        }
        if(res.length() < 1) return null;
        return res.toString();
    }



    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        for (Pair<String, Integer> pair : pairs) {
            builder.append(pair).append("\n");
        }
        return builder.toString();
    }
}
